package com.example.team11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Team11Application {

	public static void main(String[] args) {
		SpringApplication.run(Team11Application.class, args);
	}

}
